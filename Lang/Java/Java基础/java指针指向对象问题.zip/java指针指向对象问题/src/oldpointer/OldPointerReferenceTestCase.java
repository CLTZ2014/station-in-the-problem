package oldpointer;

/**
 * 测试一个引用变量引用了另一个引用变量以后，当另一个引用变量改变引用对象时，此变量会不会也被改变指向
 *
 */
public class OldPointerReferenceTestCase {

	
	public static void main(String[] args) {
		Printer printer = null;
		Printer ptr1 = new Printer("Obj 1");
		printer = ptr1;
		//重定向ptr1，观察printer是否也被改变指向
		ptr1 = new Printer("Obj 2");
		printer.print();
		//结果:Obj 1 
		//说明 当执行 printer = ptr1 赋值语句时，ptr1将堆中存放的对象首地址给printer，而不是
		//将ptr1在栈中的地址给printer
	}
}
