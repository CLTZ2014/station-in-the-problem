package oldpointer;

public class Printer {
  private String content; 
  public void print(){
	  System.out.println(content);
  }
  public Printer (String content){
	  this.content = content;
  }
}
