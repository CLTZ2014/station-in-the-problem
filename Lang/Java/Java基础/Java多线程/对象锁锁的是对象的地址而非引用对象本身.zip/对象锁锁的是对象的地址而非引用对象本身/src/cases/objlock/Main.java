package cases.objlock;


/**
 * 对象锁锁的是对象的地址而非引用对象本身
 * 具体步骤如下：
 * 1.定义一个锁
 * 2.开启一个线程持有这个对象并睡眠
 * 3.并且备份一个锁引用，将原先的锁引用重新引用一个新对象
 * 3.观察引用是否可以在其他线程持有的时候被改变，观察
 * @author zzzhuo
 *
 */
public class Main {
	//锁
   public  static Object lock = new Object();  
   
	public static void main(String[] args) throws InterruptedException {
		new Thread(new Runnable() {
			
			@SuppressWarnings("static-access")
			@Override
			public void run() {
				synchronized (Main.lock) {
					try {
						Thread.currentThread().sleep(4000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					};
				System.out.println("thread-0 end");
				}
			}
		}).start();
		Thread.sleep(1000);
		//备份锁
		Object blkLock = Main.lock;
		//如果锁住的是lock引用，那么就后于thread-0end打出，否则就相反=====
		Main.lock = new Object();
		System.out.println("====");
		//如果锁的是对象的地址，那么main-end则后于thread-0 end 打出，反正则不是锁的是对象的地址
		synchronized (blkLock) {
		  System.out.println("main end");
		}
		//结果
		/*====
		thread-0 end
		main end*/
		//对象锁锁的是对象的地址而非引用对象本身
	}

}
