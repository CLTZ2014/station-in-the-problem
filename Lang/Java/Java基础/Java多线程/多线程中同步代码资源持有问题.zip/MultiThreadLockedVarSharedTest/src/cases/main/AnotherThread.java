package cases.main;

public class AnotherThread extends Thread {
	private Printer printer;
	
	public AnotherThread(Printer printer) {
		super();
		this.printer = printer;
	}

	public Printer getPrinter() {
		return printer;
	}

	public void setPrinter(Printer printer) {
		this.printer = printer;
	}

	public void run(){
		synchronized (printer) {
			try {
				System.out.println("-------子线程准备睡眠-------");
				Thread.currentThread().sleep(2000);
				System.out.println("-------子线程睡眠结束-------");
				printer.getContent().append("---------");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
