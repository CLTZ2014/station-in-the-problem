package cases.main;

public class Printer {
	private StringBuffer content = new StringBuffer();

	public StringBuffer getContent() {
		return content;
	}

	public void setContent(StringBuffer content) {
		this.content = content;
	}
}
