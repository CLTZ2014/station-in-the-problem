package cases.main;

/**
 * 验证当一个对象被一个同步代码块持有的时候,其他没有在同步范围内的代码块也持有该对象，那么其他地方会不会等待同步代码块中释放了资源才能继续操作该对象。
 * 验证过程如下：
 * 1.定义一个持有StringBuffer域的Printer对象
 * 2.将Printer对象交给子线程AnotherThread和主线程
 * 3.在子线程中对printer进行同步。
 * 4.启动子线程时睡眠主线程1秒钟等待子线程持有printer
 * 5.在主线程睡眠的同时，子线程启动，并且进入两秒的睡眠，那么这两秒中，子线程持有printer的资源
 * 6.主线程提前苏醒，而子线程还在睡眠，没有释放printer，在主线程中append printer的content
 * 7.如果子线程中拼接的内容在主线程拼接的内容之前，那么主线程就有一秒的资源等待，如果没有拼接子线程的内容，那么主线程便没有等待
 * 也就说明在其他非同步范围内的代码块也持有一个正在运行同步代码块的内容，不需要等待其释放
 * @author zzzhuo
 *
 */
public class Main {
	
	public static void main(String[] args) throws InterruptedException {
		Printer printer = new Printer();
		//启动主线程
		AnotherThread anotherThread = new AnotherThread(printer);
		anotherThread.start();
		//主线程进入睡眠，等待子线程同步代码持有printer
		System.out.println("============主线程准备睡眠===========");
		Thread.currentThread().sleep(1000);
		System.out.println("============主线程睡眠结束===========");
		//拼接====
		printer.getContent().append("=======");
		System.out.println(printer.getContent());
		//结果，只打印了========而不是--------==========，说明主线程没有等待子线程释放printer资源就对printer进行操作。
		//其他地方不需要等待同步代码块中释放了资源才能继续操作该对象
	}
}
