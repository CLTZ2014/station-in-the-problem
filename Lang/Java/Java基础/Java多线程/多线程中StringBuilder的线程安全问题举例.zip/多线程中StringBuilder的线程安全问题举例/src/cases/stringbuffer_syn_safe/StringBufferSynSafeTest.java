package cases.stringbuffer_syn_safe;

/**
 * 测试线程安全的StringBuffer为什么是线程安全的。
 * 测试过程：
 * 1.创建一个StringBuffer和一个StringBuilder
 * 2.使用两个不同名称的线程引用这两个对象
 * 3.对其各自进行append
 * 4.在输出结果中查看有没有乱码的问题
 * 
 * @author zzzhuo
 *
 */
public class StringBufferSynSafeTest {

	public static void main(String[] args) throws InterruptedException {
		//以两个可变字符串的append方法为例，验证两者的线程安全与不安全的区别
		StringBuffer stringBuffer = new StringBuffer();
		StringBuilder stringBuilder = new StringBuilder();
		
		Thread thread1 = new Thread(new StringAppendThread(stringBuffer, stringBuilder));
		Thread thread2 = new Thread(new StringAppendThread(stringBuffer, stringBuilder));
		thread1.start();
		thread2.start();
		Thread.currentThread().sleep(2000);
		System.out.println(stringBuffer.toString());
		System.out.println(stringBuilder.toString());
		//结果，由于StringBuilderappend不具有线程安全性，所以两个线程同时对其append操作，导致字符乱码，而StringBuffer就不会
		//未出结果则多运行几次
		//append方法在StringBuffer中带有synchronized修饰，所以他可以对此对象实现同步控制。
	}

}
