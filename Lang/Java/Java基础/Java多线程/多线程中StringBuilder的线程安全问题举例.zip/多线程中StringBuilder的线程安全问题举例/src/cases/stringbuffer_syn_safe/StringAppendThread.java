package cases.stringbuffer_syn_safe;

public class StringAppendThread implements Runnable {
	
	private StringBuffer sbf;
	private StringBuilder sbd;

	public void run() {
		for(int i = 0 ; i < 100 ; i ++ ){
			sbd.append("xx");
			sbf.append("oo");
		}
	}
	
	
	public StringAppendThread(StringBuffer sbf, StringBuilder sbd) {
		super();
		this.sbf = sbf;
		this.sbd = sbd;
	}


	public StringBuffer getSbf() {
		return sbf;
	}

	public void setSbf(StringBuffer sbf) {
		this.sbf = sbf;
	}

	public StringBuilder getSbd() {
		return sbd;
	}

	public void setSbd(StringBuilder sbd) {
		this.sbd = sbd;
	}
	
	
}
