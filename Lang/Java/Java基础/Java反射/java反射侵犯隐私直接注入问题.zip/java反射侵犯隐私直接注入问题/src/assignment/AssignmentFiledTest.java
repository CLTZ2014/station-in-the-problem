package assignment;

import java.lang.reflect.Field;

/*
 * 这个类阐述两大问题:
 * 1.反射侵犯隐私直接注入，那么打在被赋值对象域上的watchpoint将不会观察到值得变化
 * 2.反射改变accessable仅仅是局限于一部分的代码，而不是改变类的结构
 */
public class AssignmentFiledTest {
    

    public static void main(String[] args) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
        //反射侵犯隐私直接注入，那么打在被赋值对象域上的watchpoint将不会观察到值得变化
        //在printer的content上打一个watchpoint，观察能否进入
        Printer printer = new Printer();
        Field field = printer.getClass().getDeclaredField("content");
        field.setAccessible(true);
        field.set(printer, "This is content");
        printer.print();
        
        //针对前面部分的代码对Accessable的改变，测试如下内容是否可以不设置accessable为true就可以直接赋值
        Printer printer2 = new Printer();
        Field field2 = printer2.getClass().getDeclaredField("content");
        field2.set(printer, "测试 在先前的代码中设置了accessAble=true,在这里不设置是否可以直接使用");
        printer2.print();
        //结果：报错。IllegalAccessException
        //也就是说，accessAble不是改变类加载器中类的内容，而是仅仅局限于一个Field中的改变
    }
    
}
