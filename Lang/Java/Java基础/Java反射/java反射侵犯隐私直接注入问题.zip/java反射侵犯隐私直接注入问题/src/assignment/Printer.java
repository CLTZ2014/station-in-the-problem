package assignment;


public class Printer {
    
    //在此处打一watchpoint
    private String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void print(){
        System.out.println(content);
    }
}
