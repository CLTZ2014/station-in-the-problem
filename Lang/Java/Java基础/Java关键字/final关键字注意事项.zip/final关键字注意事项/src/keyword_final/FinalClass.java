
package keyword_final;

import java.util.ArrayList;
import java.util.List;

import sun.reflect.generics.tree.VoidDescriptor;

/*
 * 修饰了final的class不能被其他类继承
 */
//public final class FinalClass
public  class FinalClass {
    
    
    //修饰了fianl 的 method 不能被子类覆写
    final void  print(){
        System.out.println("parent content");
    }

    
}
