
package keyword_final;

import java.util.ArrayList;
import java.util.List;

/*
 *此类说明了final的所有用法
 *1.修饰了final的类不能被其他类继承
 *2.使用了fianl修饰的方式不能被子类覆写
 *3.final 修饰的变量不能被重新赋值，但是特别注意，若果final指向对象，那么对象可以改变，但是此变量不能再引用其他的对象
 */
//若 FinalClass 使用注释中的内容，则在此处会报错
public class FinalKeywordCase extends FinalClass{
    
    //final 修饰的变量不能被重新赋值，但是特别注意，若果final指向对象，那么对象可以改变，但是此变量不能再引用其他的对象
    private final List<String> list = new ArrayList<String>();
    
    public static void main(String[] args) {
        FinalKeywordCase  caze  = new FinalKeywordCase();
        caze.getList().add("aa");
        //结果不报错
       
    }

    public List<String> getList() {
        return list;
    }
    //使用final修饰的方法不能被子类覆写
    /*@Override
    final void  print(){
        System.out.println("parent content");
    }*/
}
